-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Sep 12, 2018 at 02:28 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Database: `pro`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `collect`
-- 

CREATE TABLE `collect` (
  `id` int(10) NOT NULL auto_increment,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `tel` varchar(10) collate utf8_unicode_ci NOT NULL,
  `status` varchar(50) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=21 ;

-- 
-- Dumping data for table `collect`
-- 

INSERT INTO `collect` VALUES (1, 'karunaporn pholpan', '2018-08-07', '10:00:00', '0238765456', 'sss');
INSERT INTO `collect` VALUES (3, 'ddddd', '2018-08-10', '14:01:00', '098765432', 'uu');
INSERT INTO `collect` VALUES (11, 'jjj', '2018-08-21', '00:00:00', '1234567890', 'sd');
INSERT INTO `collect` VALUES (14, 'mayhada', '2018-08-28', '10:32:00', '0897678585', 'user');
INSERT INTO `collect` VALUES (15, 'qr', '0000-00-00', '00:00:00', '1234567890', 'vv');
INSERT INTO `collect` VALUES (19, '', '0000-00-00', '00:00:00', '', '');

-- --------------------------------------------------------

-- 
-- Table structure for table `login`
-- 

CREATE TABLE `login` (
  `user` varchar(50) collate utf8_unicode_ci NOT NULL,
  `password` varchar(10) collate utf8_unicode_ci NOT NULL,
  `statas` varchar(50) collate utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- 
-- Dumping data for table `login`
-- 

INSERT INTO `login` VALUES ('priew', '123456', 'admin');
